const express = require('express');
const path = require('path');
const http = require('http');
const socketio = require('socket.io');
const formatMessage = require('./utils/chatMessage');
const mongoClient = require('mongodb').MongoClient;

// Veritabanı bilgileri
const dbname = 'chatApp';
const chatCollection = 'chats'; // Tüm mesajları tutacak koleksiyon
const userCollection = 'onlineUsers'; // Çevrimiçi kullanıcıları tutacak koleksiyon

const port = 5000;
const database = 'mongodb://127.0.0.1:27017/chat_db';
const app = express();

// Sunucu oluşturma ve Socket.IO kurulum
const server = http.createServer(app);
const io = socketio(server);

// Yeni bir kullanıcı bağlandığında çalışacak kısım
io.on('connection', (socket) => {
    console.log('Yeni Kullanıcı Bağlandı. ID: ' + socket.id);
    
    // Kullanıcıdan mesaj alındığında veritabanına kaydetme ve iletme
    socket.on('chatMessage', (data) => {
        const dataElement = formatMessage(data);
        
        // MongoDB bağlantısı
        mongoClient.connect(database, (err, db) => {
            if (err) throw err;
            
            const onlineUsers = db.db(dbname).collection(userCollection);
            const chat = db.db(dbname).collection(chatCollection);

            // Mesajı veritabanına ekle
            chat.insertOne(dataElement, (err, res) => {
                if (err) throw err;
                // Mesajı gönderen kullanıcıya geri gönder
                socket.emit('message', dataElement);
            });

            // Mesajın alıcısının çevrimiçi olup olmadığını kontrol et
            onlineUsers.findOne({"name": data.toUser}, (err, res) => {
                if (err) throw err;
                // Alıcı çevrimiçiyse, mesajı ona gönder
                if (res != null) {
                    socket.to(res.ID).emit('message', dataElement);
                }
            });

            db.close();
        });
    });

    // Kullanıcı detaylarını aldığımız kısım (çevrimiçi kullanıcı olarak ekleme, geçmişi gönderme)
    socket.on('userDetails', (data) => {
        mongoClient.connect(database, (err, db) => {
            if (err) throw err;
            
            const onlineUser = {
                "ID": socket.id,
                "name": data.fromUser
            };
            const currentCollection = db.db(dbname).collection(chatCollection);
            const online = db.db(dbname).collection(userCollection);

            // Yeni bağlanan kullanıcıyı çevrimiçi kullanıcı listesine ekle
            online.insertOne(onlineUser, (err, res) => {
                if (err) throw err;
                console.log(onlineUser.name + " çevrimiçi oldu...");
            });

            // İki kullanıcı arasındaki tüm mesaj geçmişini bulup gönder
            currentCollection.find({
                "from": { "$in": [data.fromUser, data.toUser] },
                "to": { "$in": [data.fromUser, data.toUser] }
            }, { projection: { _id: 0 } }).toArray((err, res) => {
                if (err) throw err;
                socket.emit('output', res);
            });

            db.close();
        });   
    });  

    // Kullanıcı bağlantıyı kestiğinde çevrimiçi listeden silme
    const userID = socket.id;
    socket.on('disconnect', () => {
        mongoClient.connect(database, function(err, db) {
            if (err) throw err;

            const onlineUsers = db.db(dbname).collection(userCollection);
            const myquery = { "ID": userID };
            
            onlineUsers.deleteOne(myquery, function(err, res) {
                if (err) throw err;
                console.log("Kullanıcı " + userID + " bağlantıyı kesti.");
                db.close();
            });
        });
    });
});

// Statik dosyalara erişim
app.use(express.static(path.join(__dirname, 'front')));

// Sunucuyu dinlemeye başlatma
server.listen(port, () => {
    console.log(`Sohbet Sunucusu ${port} portunda dinleniyor...`);
});
