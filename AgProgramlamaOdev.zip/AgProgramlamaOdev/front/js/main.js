socket = io();

// Form ve mesaj listesi elementlerini seçme
const chatForm = document.getElementById('chat-form');
const chatMessages = document.querySelector('.chat-messages');

// URL'den parametre alma (Şimdilik kullanılmıyor)
const { username, room } = Qs.parse(location.search, {
  ignoreQueryPrefix: true
});

// Varsayılan kullanıcı ve alıcı isimleri
let fromUser = "Burak";
let toUser = "Ahmet";
// socket.emit('userDetails', { fromUser, toUser });

/**
 * Kullanıcı adlarını saklayıp 'userDetails' olayını tetikler.
 */
function storeDetails() {
  fromUser = document.getElementById('from').value;
  toUser = document.getElementById('to').value;
  element = document.querySelectorAll(".chat-messages");
  // Kurulu sohbetin ayrıntılarını sunucuya iletir
  socket.emit('userDetails', { fromUser, toUser });
}

/**
 * Boş bir fonksiyon; ek işlemler için kullanabilirsiniz.
 */
function storeTo() {
  // console.log(toUser);
}

/**
 * Mesaj gönderme formu gönderildiğinde tetiklenen olay.
 */
chatForm.addEventListener('submit', (e) => {
  e.preventDefault(); // Varsayılan davranışı (örneğin sayfa yenileme) engeller
  const msg = e.target.elements.msg.value;
  final = {
    'fromUser': fromUser,
    'toUser': toUser,
    'msg': msg
  };
  // Sohbet mesajını, gönderen ve alıcı bilgileriyle birlikte sunucuya iletir
  socket.emit('chatMessage', final);
  
  // Mesaj kutusunu temizle
  document.getElementById('msg').value = " ";
});

/**
 * Sunucudan gelen 'output' olayını dinler (ilk kısım - log).
 */
socket.on('output', (data) => {
  console.log(data);
});

/**
 * Sunucudan gelen 'output' olayını dinler (ikinci kısım - mesajları ekrana basma).
 * İki kullanıcı arasında oturum açıldığında tüm sohbet geçmişini alır ve gösterir.
 */
socket.on('output', (data) => {
  for (var i = 0; i < data.length; i++) {
    outputMessage(data[i]);
  }
  chatMessages.scrollTop = chatMessages.scrollHeight;
});

/**
 * Sunucudan gelen 'message' olayını dinler.
 * Yeni mesaj alındığında ekranda gösterir.
 */
socket.on('message', (data) => {
  outputMessage(data);
  console.log(data);
  chatMessages.scrollTop = chatMessages.scrollHeight;
});

/**
 * Alınan mesajları DOM'a ekleyerek görüntüler.
 */
function outputMessage(message) {
  const div = document.createElement('div');
  div.classList.add('message');
  div.innerHTML = `
    <p class="meta">
      ${message.from}<span> ${message.time}, ${message.date}</span>
    </p>
    <p class="text">
      ${message.message}
    </p>
  `;
  document.querySelector('.chat-messages').appendChild(div);
}
